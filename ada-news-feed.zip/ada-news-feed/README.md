# ADA News Feed — The Public Dispatch

Automatically fetches daily AI & Tech news and pushes it to Supabase so ADA stays current.

## How it works
- Runs every day at 8am South Africa time (6am UTC)
- Fetches from 8 trusted sources including TechCrunch AI, MIT Technology Review, The Verge, VentureBeat, Wired, TechCentral SA and MyBroadband SA
- Pushes new articles to the `ada_news` table in Supabase
- ADA reads from this table to answer questions about current AI developments

## Sources
- TechCrunch AI
- MIT Technology Review
- The Verge AI
- VentureBeat AI
- Ars Technica
- Wired AI
- TechCentral SA
- MyBroadband SA

## Setup
Add these secrets in GitHub → Settings → Secrets → Actions:
- `SUPABASE_URL` — your Supabase project URL
- `SUPABASE_KEY` — your Supabase anon key
