import feedparser
import requests
import os
from datetime import datetime, timezone
import hashlib

SUPABASE_URL = os.environ['SUPABASE_URL']
SUPABASE_KEY = os.environ['SUPABASE_KEY']

# AI & Tech RSS feeds
FEEDS = [
    {'url': 'https://feeds.feedburner.com/TechCrunch/artificial-intelligence', 'source': 'TechCrunch AI'},
    {'url': 'https://www.technologyreview.com/feed/', 'source': 'MIT Technology Review'},
    {'url': 'https://www.theverge.com/rss/ai-artificial-intelligence/index.xml', 'source': 'The Verge AI'},
    {'url': 'https://venturebeat.com/category/ai/feed/', 'source': 'VentureBeat AI'},
    {'url': 'https://feeds.arstechnica.com/arstechnica/index', 'source': 'Ars Technica'},
    {'url': 'https://www.wired.com/feed/category/artificial-intelligence/latest/rss', 'source': 'Wired AI'},
    {'url': 'https://techcentral.co.za/feed/', 'source': 'TechCentral SA'},
    {'url': 'https://mybroadband.co.za/news/feed', 'source': 'MyBroadband SA'},
]

def get_existing_urls():
    """Get URLs already in Supabase to avoid duplicates"""
    headers = {
        'apikey': SUPABASE_KEY,
        'Authorization': f'Bearer {SUPABASE_KEY}'
    }
    res = requests.get(
        f'{SUPABASE_URL}/rest/v1/ada_news?select=url&order=created_at.desc&limit=200',
        headers=headers
    )
    if res.status_code == 200:
        return {item['url'] for item in res.json() if item.get('url')}
    return set()

def clean_summary(text, max_len=300):
    """Clean and truncate summary text"""
    if not text:
        return ''
    # Remove HTML tags
    import re
    text = re.sub(r'<[^>]+>', '', text)
    text = text.strip()
    if len(text) > max_len:
        text = text[:max_len].rsplit(' ', 1)[0] + '...'
    return text

def fetch_and_push():
    print("Fetching AI news for ADA...")
    existing_urls = get_existing_urls()
    print(f"Found {len(existing_urls)} existing articles")

    new_articles = []

    for feed_info in FEEDS:
        try:
            print(f"Fetching: {feed_info['source']}")
            feed = feedparser.parse(feed_info['url'])
            
            for entry in feed.entries[:5]:  # Max 5 per source
                url = entry.get('link', '')
                if not url or url in existing_urls:
                    continue

                # Parse published date
                published = None
                if hasattr(entry, 'published_parsed') and entry.published_parsed:
                    try:
                        published = datetime(*entry.published_parsed[:6], tzinfo=timezone.utc).isoformat()
                    except:
                        published = datetime.now(timezone.utc).isoformat()
                else:
                    published = datetime.now(timezone.utc).isoformat()

                # Get summary
                summary = ''
                if hasattr(entry, 'summary'):
                    summary = clean_summary(entry.summary)
                elif hasattr(entry, 'description'):
                    summary = clean_summary(entry.description)

                article = {
                    'title': entry.get('title', '')[:500],
                    'summary': summary,
                    'source': feed_info['source'],
                    'url': url,
                    'published_at': published,
                    'category': 'AI & Tech'
                }
                new_articles.append(article)
                existing_urls.add(url)

        except Exception as e:
            print(f"Error fetching {feed_info['source']}: {e}")
            continue

    if not new_articles:
        print("No new articles found today.")
        return

    # Push to Supabase
    headers = {
        'apikey': SUPABASE_KEY,
        'Authorization': f'Bearer {SUPABASE_KEY}',
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
    }

    res = requests.post(
        f'{SUPABASE_URL}/rest/v1/ada_news',
        headers=headers,
        json=new_articles
    )

    if res.status_code in [200, 201]:
        print(f"✅ Successfully pushed {len(new_articles)} new articles to Supabase!")
    else:
        print(f"❌ Error pushing to Supabase: {res.status_code} {res.text}")

if __name__ == '__main__':
    fetch_and_push()
